import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import FloatingHearts from "@/components/FloatingHearts";
import EscapingButton from "@/components/EscapingButton";

const Index = () => {
  const [accepted, setAccepted] = useState(false);

  if (accepted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-valentine-light via-valentine to-valentine-dark flex items-center justify-center relative overflow-hidden">
        <FloatingHearts />
        <div className="z-10 text-center animate-scale-in p-8">
          <div className="text-8xl mb-6 animate-bounce">😏💘</div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 drop-shadow-lg">
            Yay! I knew you'd say yes!
          </h1>
          <p className="text-2xl md:text-3xl text-white/90 mb-8 drop-shadow">
            Best decision ever! 💕
          </p>
          <div className="text-6xl animate-pulse">
            💕 💖 💕
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-valentine-light via-valentine to-valentine-dark flex items-center justify-center relative overflow-hidden">
      <FloatingHearts />
      
      <div className="z-10 text-center p-8">
        <div className="text-6xl mb-6 animate-bounce">
          💕 💘 💕
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg animate-fade-in">
          Will You Be My Valentine?
        </h1>
        
        <p className="text-xl md:text-2xl text-white/80 mb-12 drop-shadow animate-fade-in">
          Please say yes... 🥺✨
        </p>
        
        <div className="flex flex-wrap items-center justify-center gap-6">
          <Button
            onClick={() => setAccepted(true)}
            className="text-xl px-10 py-7 font-bold bg-white text-valentine hover:bg-white/90 hover:scale-110 transition-all duration-300 shadow-xl"
          >
            Yes! 💕
          </Button>
          
          <EscapingButton>
            No 😢
          </EscapingButton>
        </div>
      </div>
    </div>
  );
};

export default Index;
