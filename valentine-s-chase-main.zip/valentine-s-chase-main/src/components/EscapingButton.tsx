import React, { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";

interface EscapingButtonProps {
  children: React.ReactNode;
}

const EscapingButton = ({ children }: EscapingButtonProps) => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isEscaping, setIsEscaping] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const escapeFromCursor = useCallback((e: React.MouseEvent) => {
    if (!buttonRef.current) return;

    const button = buttonRef.current;
    const rect = button.getBoundingClientRect();
    
    // Get viewport dimensions with padding
    const padding = 20;
    const maxX = window.innerWidth - rect.width - padding;
    const maxY = window.innerHeight - rect.height - padding;

    // Calculate a random new position away from current
    let newX = Math.random() * maxX;
    let newY = Math.random() * maxY;

    // Make sure it moves at least 100px away
    const currentCenterX = rect.left + rect.width / 2;
    const currentCenterY = rect.top + rect.height / 2;
    
    while (
      Math.abs(newX - (currentCenterX - rect.width / 2)) < 100 &&
      Math.abs(newY - (currentCenterY - rect.height / 2)) < 100
    ) {
      newX = Math.random() * maxX;
      newY = Math.random() * maxY;
    }

    // Convert to relative position from initial position
    const initialRect = button.parentElement?.getBoundingClientRect();
    if (initialRect) {
      const offsetX = newX - (rect.left - position.x);
      const offsetY = newY - (rect.top - position.y);
      
      setIsEscaping(true);
      setPosition({ x: offsetX, y: offsetY });
      
      setTimeout(() => setIsEscaping(false), 300);
    }
  }, [position]);

  return (
    <Button
      ref={buttonRef}
      variant="outline"
      onMouseEnter={escapeFromCursor}
      className={`
        relative text-lg px-8 py-6 font-bold
        bg-white/20 text-white border-2 border-white/50
        backdrop-blur-sm
        transition-all duration-300 ease-out
        hover:bg-white/30
        ${isEscaping ? "scale-110" : ""}
      `}
      style={{
        transform: `translate(${position.x}px, ${position.y}px)`,
        transition: "transform 0.3s ease-out",
      }}
      onClick={() => {
        console.log("How did you manage that?!");
      }}
    >
      {children}
    </Button>
  );
};

export default EscapingButton;
