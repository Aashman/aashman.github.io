
# 💕 Valentine's "Will You Be My Valentine?" Interactive Card

A playful, fun Valentine's themed page where the "No" button hilariously escapes from the cursor, making it impossible to reject!

## Page Design

### Visual Theme
- **Bright pink and red color scheme** with pops of white
- **Bouncy, playful typography** - fun fonts that feel cheerful
- **Animated floating hearts** scattered across the background
- **Emoji accents** (💕 💘 😏 🎉) throughout the design
- **Gradient background** transitioning from pink to red tones

### Main Content
- **Large, centered question**: "Will You Be My Valentine? 💕"
- **Character/emoji decoration** around the question (hearts, sparkles)
- **Two buttons side by side**: 
  - ✅ **"Yes!"** button - clickable, styled prominently in pink/red
  - ❌ **"No"** button - the mischievous escaping button

## Interactive Features

### The Escaping "No" Button 🏃‍♂️
- When the cursor approaches the "No" button, it will "run away" to a random position on the screen
- The button will move smoothly, as if being chased by the cursor
- Uses cursor proximity detection - the closer you get, the faster it escapes
- The button stays within the viewport boundaries so it's always visible (but never catchable!)
- Playful animation when it moves (maybe a slight bounce or shake)

### "Yes" Button Success 🎉
When clicked, displays a fun celebration screen:
- Romantic but playful message like: **"Yay! I knew you'd say yes! 😏💘"**
- Additional cute text: **"Best decision ever! 💕"**
- Heart emojis and celebratory animations
- The floating hearts animation continues/intensifies

### Floating Hearts Background
- Gentle, continuous animation of hearts floating upward across the screen
- Various heart sizes and colors (pink, red, light pink)
- Creates a dreamy, romantic atmosphere
- Hearts have slight rotation/wobble for a natural feel

## User Experience Flow
1. User lands on the page → sees the Valentine question with floating hearts
2. User tries to click "No" → button escapes, creating a fun chase
3. User eventually clicks "Yes" → celebration screen appears with a playful message
4. The whole experience is lighthearted, fun, and impossible to "fail" 💕
